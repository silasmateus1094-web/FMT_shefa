FMT SINAIS — PRD v2.5 (User Control)
=======================================
• Visual premium (dark+dourado) • RBAC • Login • Banca por usuário • Sem martingale

Primeiro acesso (Admin):
  - Usuário: admin@fmt
  - Senha inicial: LvgxWtndXM

Como publicar na Vercel (grátis):
1) Acesse https://vercel.com/new e clique em "Upload Project".
2) Envie TODO o conteúdo desta pasta ZIP (mantenha a estrutura com /public e vercel.json).
3) Projeto Static: Root Directory = public, Build Command = vazio, Output = public.
4) Deploy e use o link público (acesso exige login).

Admin → pode criar usuários e definir permissões (inclui acesso à ★ Inteligência Suprema).
Cada usuário tem sua própria Banca (isolada por e-mail).
